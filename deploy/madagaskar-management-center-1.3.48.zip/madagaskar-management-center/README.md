# Madagaskar Management Center v1.3.30

Bu sürüm **MMC Programı tek yapısal kaynak** ilkesini güçlendirir ve yayın Excel'ini yalnız içerik yönetimine ayırır.

## v1.3.30 — MMC Tek Kaynak + Zengin Yayın Excel + Otomatik Aile Paketi

- İl, ilçe, kesin salon, salon adresi, tarih, seans, ortak kapasite ve bilet fiyatları MMC Programı'ndan gelir.
- Etkinlik Yayınla ekranında MMC Programı seçimi ve güvenli MDG taslak eşitlemesi korunur.
- Satış Hazırlığı ekranındaki tek tık kesin salon bağlantısı korunur.
- Yeni yayın Excel değişkenleri: adres, uzun tarih, bilet özeti, bilgi hattı, resmî bilet linki ve etkinlik adı.
- Excel yalnız kısa/uzun açıklama, kurallar, SEO, video URL'si ve SSS alanlarını günceller; program verilerini değiştirmez.
- Aile Paketi 2+2 fiziksel üçüncü MDG bilet türü değildir; gerçek 2 yetişkin + 2 çocuk biletlerinden 4 QR üretir.
- MMC'deki family_2_2 aktiflik ve etkinlik fiyatı MDG taslağı eşitlendiğinde Aile Paketi eklentisinin etkinlik ayarına otomatik aktarılır.
- Mevcut canlı WooCommerce/Tickera/PayTR satış nesneleri otomatik değiştirilmez.
- DB şeması değişmez; `MMC_DB_VERSION` **1.3.7** olarak kalır.

---

# Madagaskar Management Center v1.3.29

Bu sürüm **v1.3.27 program/Etkinlik Yayınla köprüsünü ve v1.3.28 MDG taslak senkronunu tek sürümde birleştirir; yayın içeriği Excel akışını MMC ana verisine göre sadeleştirir.**

## v1.3.29 — Tek Kaynaklı Etkinlik Yayını + MMC Uyumlu Excel

- v1.3.26'daki **Satış Hazırlığı → tek adım kesin salon bağlama** korunur.
- v1.3.27'deki **MMC Programı → Etkinlik Yayınla** program seçici ve güvenli taslak köprüsü korunur.
- v1.3.28'deki **MMC Etkinlik & Seans → MDG Etkinlik Taslağı** senkronu eklenmiştir.
- MDG taslağının program kimliği, il/ilçe, kesin salon, tarih, seans, ortak kapasite ve gerçek Çocuk/Yetişkin fiyatları yalnız MMC'den gelir.
- MMC'deki `family_2_2` fiyatı MDG'de kapasite-4 üçüncü gerçek bilet satırına çevrilmez; Aile Paketi modülü 2 Çocuk + 2 Yetişkin gerçek bileti kullanır.
- **Etkinlik Yayınla** ekranına bağlı programlarda **Yayın İçeriği Excel — MMC Uyumlu** paneli eklenmiştir.
- Excel yalnız kısa/uzun yayın metni, kurallar, SEO, video URL'si ve SSS günceller.
- Salon/tarih/seans/kapasite/fiyat Excel'den değiştirilemez.
- Satışa açılmış MDG etkinliği otomatik senkron ve Excel içeriği güncellemesinden korunur.
- Canlı WooCommerce/Tickera/PayTR verisine dokunulmaz.
- DB şeması değişmez; `MMC_DB_VERSION` **1.3.7** olarak kalır.

---

# Madagaskar Management Center v1.3.27

Bu sürüm **MMC programlarını eski MDG Etkinlik Yayınla ekranına yeniden veri girmeden aktarır**.

## v1.3.27 — MMC → Etkinlik Yayınla Köprüsü

- `mdg-publish?program_id=...` artık MMC program kimliğini kullanır.
- Etkinlik Yayınla ekranının üstünde **MMC Programından Etkinlik Taslağı** paneli gösterilir.
- Panelde aktif programlar seçilebilir; mevcut `program_id` otomatik seçili gelir.
- Program özeti: program kodu, şehir/ilçe, tarih, kesin salon, seans sayısı ve bilet türü sayısı.
- **MMC Programından Taslak Oluştur** işlemi kesin salonu mevcut MDG Salonlar ana kaydına bağlar; tarih, seans, ortak kapasite, aktif bilet türleri ve kendi site fiyatlarını taşır.
- Aile paketi `AILE_2_2` kodu ve 4 kişi kapasite tüketimiyle aktarılır.
- Yalnız MDG **taslak** etkinliği oluşturulur. Canlı WooCommerce ürünü, Tickera bileti/QR, PayTR ödemesi veya mevcut sipariş oluşturulmaz/değiştirilmez.
- Aynı MMC programı ikinci kez çalıştırılırsa bridge/import_code kontrolüyle duplicate taslak üretilmez.
- Aynı tarih + şehir/ilçe + salon + seans yapısında mevcut MDG etkinliği varsa yeni kayıt yerine mevcut kayıt bağlanır; birden fazla aday varsa işlem durur.
- Oluşturulan MDG taslağı MMC Program ID ile `mmc_mdg_event_bridge` üzerinden eşleştirilir.
- Görseller MMC'den zorla taşınmaz; kapak/galeri MDG taslak ekranında tamamlanır.
- DB şeması değişmez; MMC_DB_VERSION **1.3.7** olarak kalır.

---

# Madagaskar Management Center v1.3.26

Bu sürüm **salon bağlama işlemini Satış Hazırlığı ekranında tek adıma indirir**.

## v1.3.26 — Hızlı Kesin Salon Bağlantısı

- “Kesin salon bağlantısı eksik.” uyarısı görüldüğünde aynı ekranda **Kesin Salonu Hemen Bağla** alanı açılır.
- Salon ana kaynağı yine **Madagaskar → Salonlar** ekranıdır; MMC ikinci salon ana kaydı oluşturmaz.
- Liste yalnız programın ili içindeki salonları gösterir.
- Aynı ilçedeki salonlar **Önerilen** grubunda en üstte gösterilir.
- Seçilen salon programın salon adaylarına eklenir (zaten varsa mevcut kayıt kullanılır), kesin salon yapılır ve mevcut MMC etkinliğinin program_venue_id alanına bağlanır.
- Hızlı bağlantı **program yaşam döngüsü durumunu geriye çekmez**. Örneğin “Satışa Hazırlanıyor” programı “Salon Kesinleşti” aşamasına dönmez.
- Satışa açık ürün, WooCommerce siparişi, Tickera bileti/QR, PayTR ve MDG satış verisi değiştirilmez.
- DB şeması değişmez; MMC_DB_VERSION **1.3.7** olarak kalır.

---

# Madagaskar Management Center v1.3.25

Bu sürüm **tek Madagaskar yönetim menüsü** hedefini tamamlar. Mevcut MMC, MDG Bilet Yönetimi, Madagaskar V4 ve Okul Tanıtım sayfalarının callback/slug yapısı korunur; yalnız WordPress yönetim navigasyonu tek üst menü altında konsolide edilir.

## v1.3.25 — Tek Madagaskar Menüsü

- Canonical üst menü: `mmc-dashboard` → **Madagaskar**.
- Aşağıdaki legacy üst menüler, ilgili eklenti aktifse admin menüden gizlenir:
  - `mdg-dashboard` — Madagaskar Bilet Yönetimi
  - `madagaskar-v4` — Madagaskar V4
  - `mad-okul` — Okul Tanıtım
  - `madagaskar-etkinlik-yayinla` — eski tekil Etkinlik Yayınla menüsü
- Sayfalar silinmez ve callback'ler yeniden yazılmaz.
- Eski `admin.php?page=...` URL'leri çalışmaya devam eder.
- MMC devre dışı bırakılırsa legacy eklentilerin kendi üst menüleri otomatik geri gelir.
- Yetki koruması:
  - yalnız `mmc_view_dashboard` yetkisi olan kullanıcıda konsolidasyon uygulanır,
  - bu yetkisi olmayan legacy kullanıcıların mevcut menü erişimi bozulmaz.
- **Bilet Yönetimi** hub artık eski MDG çekirdeği olmasa bile V4 veya bilinen legacy etkinlik menüsü varsa görünür.
- V4 ekranları işlevlerine göre dağıtılır:
  - Genel Bakış / Erteleme-Aktarım → Bilet Yönetimi
  - Satış Yönetimi / Biletlerim → Satış & Müşteri
  - Entegrasyonlar / Geçiş Merkezi → Sistem & Yetkiler
- Eski MDG ekranlarının mevcut dağılımı korunur:
  - salon/etkinlik → Salon & Etkinlik
  - satış/müşteri → Satış & Müşteri
  - pazarlama → Pazarlama
  - CRM/Kommo → Kommo & AI
  - gider/kârlılık/finans → Finans
  - entegrasyon/geliştirici → Sistem & Yetkiler
- Okul Tanıtım ekranları **Okul Tanıtım & Saha** merkezinde kalır.
- Legacy sayfa açıldığında WordPress sol menü vurgusu tekrar **Madagaskar** üst menüsüne ve doğru MMC hub'ına döner.
- Bilinen üst menüleri salt-okunur kontrol etmek için `MMC_Navigation_Admin::navigation_health()` eklendi.
- DB şeması değişmez; `MMC_DB_VERSION` **1.3.7** olarak kalır.

## Güvenlik

- WooCommerce siparişleri, Tickera biletleri/QR, PayTR, MDG order_map ve okul kayıtları değiştirilmez.
- Menü birleştirme yalnız görünür navigasyon katmanıdır.
- Eski plugin sayfalarının kayıtları ve doğrudan URL erişimi korunur.
- Legacy kullanıcının MMC yetkisi yoksa eski menüler gizlenmez.
- Kommo ve Direct Text Source davranışı değişmez.

---

# Madagaskar Management Center v1.3.24

Bu sürüm **Kommo Token Geçiş Merkezi** ekler ve `MS_KOMMO_TOKEN → MMC_KOMMO_TOKEN` geçişini canlı bağlantıyı kesmeden doğrulanabilir hale getirir.

## v1.3.24 — Kommo Token Geçiş Merkezi

- `MMC_KOMMO_TOKEN` ve legacy `MS_KOMMO_TOKEN` ayrı ayrı salt-okunur Kommo `/api/v4/account` çağrısıyla doğrulanır.
- Token değerleri:
  - ekranda gösterilmez,
  - WordPress option/veritabanına kaydedilmez,
  - loglara yazılmaz.
- İki token aynı anda tanımlıysa güvenli runtime seçim yapılır:
  - ikisi de canlı ve aynı Kommo hesabındaysa → `MMC_KOMMO_TOKEN` aktif olur,
  - yeni token başarısız, legacy canlıysa → otomatik güvenli fallback ile `MS_KOMMO_TOKEN` kullanılır,
  - iki token farklı canlı hesaplara gidiyorsa → legacy kaynak korunur ve hesap uyuşmazlığı kritik gösterilir,
  - yalnız yeni token varsa → yeni token kullanılır,
  - yalnız legacy varsa → legacy kullanılır.
- Geçiş durumları:
  - `legacy_only`
  - `fallback_legacy`
  - `ready_to_remove_legacy`
  - `account_mismatch`
  - `complete`
  - invalid/not configured durumları.
- **Kommo → Entegrasyon Ayarları** ekranına **Kommo Token Geçiş Merkezi** eklendi.
- Ekranda yalnız güvenli metadata gösterilir:
  - constant tanımlı mı,
  - canlı mı,
  - Kommo hesap adı ve Account ID,
  - aktif runtime token kaynağı,
  - geçiş kararı.
- `Tokenları Yeniden Test Et` düğmesi iki kaynağı force-refresh ile yeniden doğrular.
- Legacy-only durumda güvenli wp-config şablonu gösterilir:
  - gerçek token değeri hiçbir zaman ekrana basılmaz.
- Yeni token aynı hesaba doğrulanmadan eski tokenı kaldırma önerisi gösterilmez.
- **Kurulum & Sağlık** ekranındaki Kommo Secret Kaynağı kontrolü artık geçiş durumunu anlayarak:
  - Sağlıklı,
  - Uyarı,
  - Kritik
  seviyelerini doğru üretir.
- DB şeması değişmez; `MMC_DB_VERSION` **1.3.7** olarak kalır.

## Güvenli geçiş sırası

1. Mevcut `MS_KOMMO_TOKEN` çalışırken bırakılır.
2. Aynı veya yenilenmiş yetkili token `wp-config.php` içinde `MMC_KOMMO_TOKEN` olarak tanımlanır.
3. **Tokenları Yeniden Test Et** çalıştırılır.
4. Yeni token aynı Kommo hesabına yeşil doğrulanır.
5. Sistem aktif runtime kaynağını `MMC_KOMMO_TOKEN` olarak gösterir.
6. Ancak bundan sonra legacy `MS_KOMMO_TOKEN` tanımı/snippet'i kaldırılır.
7. Tekrar test edilir; sonuç `complete` olmalıdır.

## Güvenlik

- Yanlış yeni token canlı sistemi otomatik kesmez; dual-token geçişte legacy fallback korunur.
- Farklı hesaplara giden iki canlı token varsa yeni tokene otomatik geçilmez.
- Secret/fingerprint kullanıcı arayüzünde gösterilmez.
- CRM lead/pipeline/status, Direct Text Source, WooCommerce, Tickera, PayTR ve MDG satış zinciri değiştirilmez.

---

# Madagaskar Management Center v1.3.23

Bu sürüm **Kommo Direct Text Source Bridge** ekler. Amaç, URL crawler/parsing hatasını tamamen bypass ederek MMC Program Dosyasını Kommo AI’ye doğrudan metin kaynağı olarak göndermektir.

## v1.3.23 — Kommo Direct Text Source Bridge

- Kommo’nun resmî `POST https://airewriter.kommo.com/api/v2/sources/text` endpoint’i kullanılır.
- Gönderilen alanlar:
  - `name`
  - `lang`
  - `text`
  - `available_functions`
- Authorization mevcut Kommo Bearer token ile yapılır.
- Direct-text source **otomatik oluşturulmaz**.
- Admin ekranında açık onay gerekir:
  - checkbox,
  - nonce,
  - tam **MMC TEXT SOURCE KUR** onay metni,
  - tarayıcı confirmation.
- İlk başarılı kurulumda:
  - yeni Kommo AI text source ID alınır,
  - `mmc_kommo_profiles.ai_source_id` bu ID’ye bağlanır,
  - `ai_synced_hash` MMC Program Dosyası hash’i ile eşitlenir,
  - `ai_source_status = synced`,
  - AI taşıma modu program bazında `text` olur.
- Önceki URL source ID güvenli referans olarak tutulur; Kommo API ile otomatik silinmez.
- Eski URL kaynağı Kommo arayüzünde hata durumunda kalıyorsa direct-text doğrulandıktan sonra kullanıcı tarafından kaldırılabilir.
- Program verisi daha sonra değişirse:
  - yeni text source kopyası otomatik oluşturulmaz,
  - durum `refresh_needed` olur,
  - dokümante edilmemiş update/delete endpoint kullanılmaz.
- URL taşıma yöntemi fallback/tanı yolu olarak korunur.
- Direct-text taşıma aktifken **Kommo’da Yeniden Tarandı Olarak İşaretle** URL işlemi kullanılmaz.
- Program Bütünlüğü ekranında AI taşıma tipi:
  - `url`
  - `direct-text`
  olarak görünür.
- DB şeması değişmez; `MMC_DB_VERSION` **1.3.7** olarak kalır.

## Güvenlik

- Mevcut CRM lead/pipeline/status köprüsüne dokunulmaz.
- WooCommerce, Tickera, PayTR ve MDG satış zinciri değişmez.
- Direct-text source yalnız açık kullanıcı onayıyla oluşturulur.
- Token hiçbir option/log içine yazılmaz.
- API yanıtından yalnız source ID ve güvenli metadata saklanır.
- Eski URL source otomatik silinmez.
- Aynı program için otomatik duplicate text source üretilmez.

---

# Madagaskar Management Center v1.3.22

Bu sürüm **Kommo AI URL bilgi kaynağını semantik HTML web sayfası olarak sunar** ve crawler erişimini tanılamak için son kaynak isteğini kaydeder.

## v1.3.22 — Kommo AI Semantik HTML Kaynağı

- v1.3.21 sonrasında tokenlı URL tarayıcıda erişilebilir olmasına rağmen Kommo kaynak satırında **Hata / 0 alt bölüm** durumu devam ettiği için parser uyumluluğu güçlendirildi.
- Aynı tokenlı kaynak URL değişmeden korunur; Kommo'da yeni kaynak oluşturmak gerekmez.
- Kaynak yanıtı artık:
  - `Content-Type: text/html; charset=utf-8`
  - `Content-Language: tr`
  - geçerli `<!doctype html>`
  - `<html lang="tr">`
  - `<title>`, `<h1>`, `<h2>`, `<p>`, `<ul>/<li>`
  gibi semantik HTML yapılarıyla servis edilir.
- Mevcut MMC Program Dosyası metni tek doğruluk kaynağı olmaya devam eder; HTML çıktı bu metinden güvenli biçimde üretilir.
- Başlıklar, madde işaretleri ve anahtar/değer satırları crawler'ın daha kolay bölümlemesi için HTML yapısına dönüştürülür.
- Robots engeli yoktur; tokenlı URL site menüsü veya sitemap içine eklenmez.
- Kaynak endpoint'ine gelen son istek:
  - tarih/saat,
  - User-Agent,
  - Accept başlığı
  ile güvenli teşhis amacıyla WordPress option içinde tutulur.
- IP adresi ve token değeri loglanmaz.
- Kommo & AI ekranında:
  - **semantik HTML**
  - content type
  - robots durumu
  - son kaynak isteği zamanı ve User-Agent
  görünür.
- Böylece yeniden tarama sonrası:
  - Kommo crawler isteği endpoint'e ulaşıyor mu,
  - yoksa istek WordPress/WAF katmanına hiç gelmiyor mu
  ayrıştırılabilir.
- Kommo taraması başarılı olmadan **Kommo'da Yeniden Tarandı Olarak İşaretle** kullanılmamalıdır.
- DB şeması değişmez; `MMC_DB_VERSION` **1.3.7** olarak kalır.

## Güvenlik

- Kaynak URL/token değişmez.
- Token sitemap, menü veya genel sayfalarda yayınlanmaz.
- HTML yalnız MMC'nin doğrulanmış Program Dosyası içeriğini verir.
- Kullanıcı kaynak metninden gelen tüm HTML karakterleri escape edilir.
- Script, iframe veya üçüncü taraf kaynak eklenmez.
- CRM Lead/Pipeline ve WooCommerce/Tickera davranışı değişmez.

---

# Madagaskar Management Center v1.3.21

Bu sürüm **Kommo AI URL bilgi kaynağının crawler tarafından parse edilebilmesini** düzeltir.

## v1.3.21 — Kommo AI URL Kaynak Erişilebilirlik Düzeltmesi

- Kommo AI bilgi kaynakları ekranında URL kaynağının **Hata / 0 alt bölüm** durumuna düşmesine yol açabilecek robots engeli kaldırıldı.
- Tokenlı MMC kaynak endpoint'i artık:
  - HTTP 200,
  - `Content-Type: text/plain; charset=utf-8`,
  - `Content-Language: tr`,
  - `X-Content-Type-Options: nosniff`
  ile servis edilir.
- Kaynak endpoint'inde artık `X-Robots-Tag: noindex, nofollow, noarchive` gönderilmez.
- URL hâlâ uzun, rastgele token içerir ve site navigasyonu/sitemap içinde yayınlanmaz.
- Kommo & AI ekranında **URL teslim durumu** görünür:
  - crawler-okunabilir,
  - content type,
  - dil,
  - robots engeli,
  - tokenlı adres bilgisi.
- Mevcut source URL/token değişmez; Kommo'da yeni kaynak oluşturmak gerekmez.
- Güncellemeden sonra Kommo'daki mevcut URL kaynağı **Update / yeniden tara** ile tekrar parse edilmelidir.
- Kommo taraması başarıyla tamamlanmadan MMC'deki **Kommo'da Yeniden Tarandı Olarak İşaretle** düğmesine basılmamalıdır.
- DB şeması değişmez; `MMC_DB_VERSION` **1.3.7** olarak kalır.

## Güvenlik

- Kaynak URL tokenlı kalır.
- Token URL sitemap/menu içinde yayınlanmaz.
- Kaynak sadece doğrulanmış MMC Program Dosyası metnini verir.
- Kommo token/secret davranışı değişmez.
- CRM lead ve pipeline davranışı değişmez.

---

# Madagaskar Management Center v1.3.20

Bu sürüm **otomatik Kommo program aşama senkronunu hızlandırır, geçici API hatalarında kontrollü retry ekler ve Program Bütünlüğü ekranında Kommo kart/aşama mutabakatını görünür hale getirir.**

## v1.3.20 — Otomatik Program Aşama Senkronu & Kommo Sağlık Özeti

- MMC program/event/session/ticket/integration/salon/finans değişiklikleri mevcut `mmc_program_logged` zinciri üzerinden Kommo kuyruğuna otomatik alınmaya devam eder.
- 15 dakikalık güvenlik cron'una ek olarak değişiklik sonrası **30 saniyelik hızlı tek-seferlik Kommo kuyruk çalışması** istenir.
- WordPress cron çalışması ziyaret/istek tetiklemeli olduğundan 30 saniye mutlak gerçek-zaman garantisi değildir; ilk uygun WordPress isteğinde çalışır.
- Kommo kuyruk hataları artık türüne göre ayrılır:
  - yapılandırma/pipeline eksik → `waiting_config`
  - HTTP/network geçici hata → kontrollü retry
  - yapısal/yetki/validation hatası → doğrudan `error`
- Retry yalnız şu durumlarda yapılır:
  - WordPress HTTP network hataları,
  - HTTP 408,
  - HTTP 429,
  - HTTP 5xx.
- Retry aralıkları:
  - 1. başarısız deneme → 5 dakika
  - 2. başarısız deneme → 15 dakika
  - 3. başarısız deneme → 30 dakika
  - toplam 4 denemeden sonra kalıcı `error`.
- HTTP 400/401/403 gibi hatalar körlemesine yeniden denenmez.
- Forward-only Kommo status köprüsü v1.3.19 davranışı aynen korunur:
  - yalnız ileri aşama PATCH edilir,
  - aynı aşamada status gönderilmez,
  - Kommo kartı ilerideyse geriye çekilmez,
  - pipeline uyuşmazlığında otomatik taşıma yapılmaz.
- Yeni `queue_health()` özeti program bazında queued/running/waiting/error/done durumlarını raporlar.
- **Program Bütünlüğü → Kommo / AI** satırı artık:
  - MMC Kommo profil ID,
  - Kommo Lead ID,
  - CRM durumu,
  - AI kaynak durumu,
  - mevcut Kommo aşaması,
  - hedef MMC aşaması,
  - ileri senkron/fark durumu,
  - bekleyen kuyruk sayısı,
  - geçmiş/son kuyruk hatası
  bilgilerini tek satırda gösterir.
- Kommo kartı hedef aşamadaysa satır sağlıklı olabilir.
- Hedefe ilerleme bekliyorsa, AI kaynağı `refresh_needed` ise veya kuyruk bekliyorsa Uyarı gösterilir.
- Kommo kartı beklenen MMC Program pipeline dışında ise Kritik gösterilir.
- DB şeması değişmez; `MMC_DB_VERSION` **1.3.7** olarak kalır.

## Güvenlik

- Otomatik kuyruk mevcut Lead ID üzerinde çalışır; kopya program kartı üretmez.
- Retry yalnız geçici hata sınıflarında yapılır.
- 400 validation ve yetki hataları tekrar tekrar Kommo'ya gönderilmez.
- Mevcut satış/WooCommerce/Kurumsal pipeline'larına dokunulmaz.
- İptal durumu hâlâ manuel Kommo yönetimindedir.
- Token/secret davranışı değişmez.

---

# Madagaskar Management Center v1.3.19

Bu sürüm **MMC Program Yaşam Döngüsü → Kommo Status Köprüsü** ekler ve mevcut kartların sıradan senkronla yanlışlıkla tekrar **Hazırlık** aşamasına çekilmesini engeller.

## v1.3.19 — Program Yaşam Döngüsü → Kommo Status Köprüsü

- Kommo program kartının mevcut `pipeline_id` ve `status_id` değeri senkron öncesinde salt-okunur okunur.
- MMC program durumları 10 Kommo program aşamasına konservatif olarak eşlenir:
  - Hazırlık → Hazırlık
  - Bölge Analizi / salon araştırması / tahsis bekleme → Bölge Planlandı
  - Salon Kesinleşti / Salon Ödemeleri → Salon/Tahsis Hazır
  - Etkinlik Hazırlığı → Etkinlik/Seans Hazır
  - Satışa Hazırlanıyor / Satışta → Satış Hazır
  - Tanıtım / Reklam → Tanıtım/Saha Aktif
  - Operasyon Hazırlığı / Gösteri Günü → Operasyon Hazır
  - Finansal Kapanış → Gösteri Tamamlandı
  - Teminat İadesi Bekleniyor → Finans/Kapanış
  - Tamamlandı → Arşiv
  - İptal → otomatik status değişikliği yapılmaz; manuel yönetim
- Mevcut Kommo kartı hedef aşamadan ilerideyse **geriye alınmaz**.
- Kart MMC dışı bir status'taysa otomatik status değişikliği yapılmaz.
- Kart beklenen MMC Program pipeline dışındaysa otomatik pipeline taşıması yapılmaz ve senkron hata verir.
- Yeni program kartı, MMC durumuna karşılık gelen hedef aşamada oluşturulur.
- Mevcut kartta status PATCH yalnız **ileri hareket gerekiyorsa** gönderilir.
- Eski davranıştaki her senkron PATCH'inde varsayılan `Hazırlık` status'unu yeniden gönderme kaldırıldı.
- Kommo & AI ekranına **Kommo Program Durum Köprüsü** paneli eklendi:
  - MMC Program Durumu
  - Kommo Mevcut Aşama
  - Hedef Aşama
  - Köprü Kararı
  - ileri taşıma / aynı aşama / geriye alma engeli / manuel durum açıklaması
- Kommo kart snapshot'ı kısa süre cache edilir; gerçek senkron sırasında zorunlu yeniden okunur.
- Status hareketleri MMC log'una `kommo_program_status_advanced` olarak yazılır.
- DB şeması değişmez; `MMC_DB_VERSION` **1.3.7** olarak kalır.

## Güvenlik

- Normal senkron mevcut Kommo kartını geriye taşımaz.
- Pipeline uyuşmazlığında otomatik taşıma yapılmaz.
- İptal durumunda otomatik status hareketi yapılmaz.
- Mevcut satış/WooCommerce/Kurumsal pipeline'larına dokunulmaz.
- Lead kopyası oluşturulmaz; mevcut `kommo_lead_id` üzerinde güncelleme yapılır.
- Token/secret davranışı değişmez.

---

# Madagaskar Management Center v1.3.18

Bu sürüm **Kommo pipeline oluşturma isteğini resmi API şemasına uygun hale getirir.**

## v1.3.18 — Kommo Embedded Statuses Fix

- v1.3.17 ile hata teşhisinde görülen:
  - `Kommo API 400 [/api/v4/leads/pipelines]`
  - `FieldMissing _embedded`
  hatası giderildi.
- Yeni `MMC — Program Yönetimi` pipeline oluşturulurken 10 MMC aşaması artık ilk pipeline POST isteğinin içinde:
  - `_embedded.statuses`
  alanı altında birlikte gönderilir.
- Böylece Kommo'nun **Add pipelines** endpoint'inin zorunlu pipeline-stage yapısına uyulur.
- Pipeline zaten varsa davranış değişmez:
  - kopya pipeline oluşturulmaz,
  - yalnız eksik MMC aşamaları `/statuses` endpoint'i üzerinden tamamlanır.
- Oluşturma sonrası pipeline tekrar salt-okunur okunur ve 10/10 aşama doğrulanır.
- Başarılı doğrulama sonrası **Hazırlık** status'u varsayılan MMC Program Status olur.
- Kommo'nun resmi desteklediği stage renkleri kullanılmaya devam eder.
- Son kurulum teşhis ekranı ve admin-rights ön kontrolü korunur.
- Veritabanı şeması değişmez; `MMC_DB_VERSION` **1.3.7** olarak kalır.

## Güvenlik

- Mevcut Satış, WooCommerce, Kurumsal Talepler ve diğer pipeline'lar değiştirilmez.
- Otomatik kurulum yok; açık kullanıcı onayı gerekir.
- Lead/müşteri/sipariş oluşturulmaz.
- Token/Authorization verileri loglanmaz veya ekranda gösterilmez.

---

# Madagaskar Management Center v1.3.17

Bu sürüm **Kommo Program Pipeline kurulumunun sessiz başarısızlıklarını teşhis eder** ve pipeline/stage yazma yetkisini kurulumdan önce salt-okunur doğrular.

## v1.3.17 — Kommo Kurulum Ön Kontrol & Hata Tanı

- Kommo `/account` yanıtındaki `current_user_id` okunur.
- Mevcut tokenın bağlı olduğu kullanıcı, `GET /api/v4/users/{id}` üzerinden salt-okunur doğrulanır.
- Kullanıcının `rights.is_admin` alanı görüntülenir:
  - Yönetici doğrulandı → kurulum devam edebilir.
  - Yönetici değil → pipeline kurulum düğmesi devre dışı bırakılır.
  - Yetki endpoint'i doğrulanamazsa → durum açıkça "Doğrulanamadı" gösterilir; kurulum denemesi ayrıntılı hata kaydı üretir.
- Kommo resmi API kuralı nedeniyle pipeline/stage oluşturma işlemleri yönetici yetkisine ihtiyaç duyar.
- API 4xx/5xx hata mesajları artık endpoint yolu ile birlikte ayrıştırılır.
- Validation error içeriği varsa güvenli/sade metin olarak kullanıcıya gösterilir.
- Son pipeline kurulum denemesi WordPress option içinde yalnız güvenli teşhis bilgisiyle saklanır:
  - tarih,
  - başarı/hata,
  - hata kodu,
  - HTTP status,
  - endpoint,
  - pipeline/status ID.
- Token, Authorization header veya API response secretları saklanmaz.
- Kurulum POST yönlendirmesi aktif `program_id` değerini korur.
- Böylece kullanıcı kurulumdan sonra aynı program ekranında kalır ve sonucu görür.
- DB şeması değişmez; `MMC_DB_VERSION` **1.3.7** olarak kalır.

## Güvenlik

- Admin ön kontrolü salt-okunur GET çağrısıdır.
- Pipeline kurulumu yine yalnız açık checkbox + tam onay metni + nonce ile çalışır.
- Mevcut Kommo pipeline'ları değiştirilmez.
- Lead/sipariş/müşteri oluşturulmaz.
- Token değeri hiçbir teşhis kaydına yazılmaz.

---

# Madagaskar Management Center v1.3.16

Bu sürüm **Kommo Program Pipeline Kurulum Merkezi** ekler. Kullanıcı açık onay vermeden Kommo'da hiçbir yazma işlemi yapılmaz.

## v1.3.16 — Kommo Program Pipeline Kurulum Merkezi

- Hedef pipeline adı: **MMC — Program Yönetimi**
- MMC program yaşam döngüsü için 10 aşama:
  1. Hazırlık
  2. Bölge Planlandı
  3. Salon/Tahsis Hazır
  4. Etkinlik/Seans Hazır
  5. Satış Hazır
  6. Tanıtım/Saha Aktif
  7. Operasyon Hazır
  8. Gösteri Tamamlandı
  9. Finans/Kapanış
  10. Arşiv
- Kurulum idempotenttir:
  - aynı isimli MMC pipeline zaten varsa yeni kopya oluşturulmaz,
  - yalnız eksik MMC aşamaları eklenir,
  - tüm aşamalar mevcutsa Kommo'ya yazma yapılmaz.
- Mevcut Satış, WooCommerce, Kurumsal Talepler ve diğer pipeline'lar değiştirilmez.
- Pipeline kurulumu için:
  - WordPress yetki kontrolü,
  - nonce,
  - onay checkbox'ı,
  - tam **MMC PROGRAM PIPELINE KUR** onay metni,
  - tarayıcı confirmation
  birlikte gereklidir.
- Kurulum tamamlandığında MMC:
  - yeni pipeline ID'yi doğrular,
  - 10/10 beklenen aşamayı yeniden okur,
  - **Hazırlık** status ID'sini varsayılan program status olarak bağlar,
  - `mmc_kommo_pipeline_id` ve `mmc_kommo_status_id` ayarlarını günceller.
- Kurulum işlemi hiçbir program lead'i oluşturmaz; Kırıkkale veya başka bir programın CRM senkronu ayrıca manuel başlatılır.
- Sağlık merkezinde yeni **MMC Program Pipeline Şeması** kontrolü:
  - kurulmadıysa Bilgi,
  - eksik aşama varsa Uyarı,
  - 10/10 doğrulanırsa Sağlıklı
  gösterir.
- DB şeması değişmez; `MMC_DB_VERSION` **1.3.7** olarak kalır.

## Kommo API yaklaşımı

Kommo pipeline ve stage oluşturma işlemleri yalnız açık kullanıcı onayından sonra yapılır. Pipeline/stage katalog okuma çağrıları salt-okunur kalır. Sistem stage'leri Kommo tarafından ayrıca yönetilir; MMC yalnız program yaşam döngüsü için düzenlenebilir aşamaları oluşturur.

## Güvenlik

- Pipeline kurulumu plugin aktivasyonunda veya cron ile otomatik çalışmaz.
- Mevcut pipeline ID'leri patch/delete edilmez.
- Lead, müşteri veya sipariş kaydı oluşturulmaz.
- WooCommerce/Tickera/PayTR/MDG/Okul Tanıtım verilerine yazma yoktur.
- Kommo tokenı ekranda veya WordPress option alanında saklanmaz/gösterilmez.
- Partial hata durumunda mevcut MMC pipeline silinmez; kurulum tekrar çalıştırıldığında eksik aşamalardan devam eder.

---

# Madagaskar Management Center v1.3.15

Bu sürüm **Kommo Pipeline Keşif Merkezi** ekler. Kommo hesabındaki mevcut lead pipeline ve status'lar salt-okunur keşfedilir; MMC Program Pipeline/Status seçimi ID yazmak yerine ekrandan yapılır.

## v1.3.15 — Kommo Pipeline Keşif Merkezi

- Kommo `/api/v4/leads/pipelines` endpoint'i salt-okunur taranır.
- Pipeline listesi ve her pipeline içindeki status adları/ID'leri MMC ekranında gösterilir.
- Liste 10 dakika cache edilir; **Pipeline Listesini Yenile** düğmesi manuel salt-okunur yenileme yapar.
- MMC Program Pipeline artık dropdown üzerinden seçilebilir.
- Varsayılan Program Status, seçilen pipeline'a ait status listesinden seçilir.
- Pipeline değiştirildiğinde status dropdown'u tarayıcıda otomatik yenilenir.
- Kaydetme sırasında seçilen pipeline Kommo hesabında yeniden doğrulanır.
- Status seçilmişse gerçekten seçilen pipeline'a ait olduğu doğrulanır.
- Geçersiz/eski pipeline veya başka pipeline'a ait status kaydedilmez.
- Eski `MS_KOMMO_PIPELINE_ID` keşif listesinde **legacy sipariş pipeline adayı** olarak etiketlenir; otomatik seçilmez.
- Sağlık ekranında seçili pipeline ve status isimleri ID'leriyle birlikte gösterilir.
- Kommo hesabında hiçbir pipeline/status oluşturulmaz, güncellenmez veya silinmez.
- Veritabanı şeması değişmez; `MMC_DB_VERSION` **1.3.7** olarak kalır.

## Güvenlik

- Keşif ve doğrulama çağrıları GET/salt-okunurdur.
- Token değeri ekranda veya WordPress option alanında tutulmaz.
- Pipeline seçimi yalnız MMC'nin `mmc_kommo_pipeline_id` ve `mmc_kommo_status_id` WordPress ayarlarını değiştirir.
- WooCommerce sipariş pipeline'ı ile MMC Program Pipeline otomatik birleştirilmez.
- Lead, müşteri, sipariş, Tickera, PayTR, MDG ve Okul Tanıtım kayıtlarına yazma yoktur.

---

# Madagaskar Management Center v1.3.14

Bu sürüm **mevcut çalışan Kommo entegrasyonunu MMC'ye güvenli biçimde köprüler ve canlı API/pipeline teşhisini sağlık merkezine taşır.**

## v1.3.14 — Kommo Legacy Bridge & Connection Diagnostics

- MMC Kommo servisi önce `MMC_KOMMO_TOKEN` / `MMC_KOMMO_SUBDOMAIN` kullanır.
- Geçiş döneminde bu değerler yoksa mevcut `MS_KOMMO_TOKEN` ve `MS_KOMMO_BASE_URL` sabitlerinden salt-okunur fallback yapabilir.
- Legacy token değeri hiçbir MMC ekranında gösterilmez, veritabanına kopyalanmaz veya loglanmaz.
- Canlı bağlantı testi Kommo `/api/v4/account` endpoint'ine salt-okunur GET çağrısı yapar.
- Bağlantı sonucu 10 dakika cache edilir; sağlık ekranı her açılışta gereksiz API çağrısı yapmaz.
- Sağlık merkezinde artık ayrı kontroller vardır:
  - **Kommo API** — canlı bağlantı ve hesap doğrulaması,
  - **Kommo Secret Kaynağı** — MMC secret mı, legacy secret mı,
  - **Kommo Program Pipeline** — explicit MMC pipeline doğrulaması.
- Eski `MS_KOMMO_PIPELINE_ID` yalnız legacy bilgi/adayı olarak gösterilir; otomatik MMC Program Pipeline yapılmaz.
- Explicit Program Pipeline ID tanımlıysa Kommo API'den pipeline ve Status ID üyeliği doğrulanır.
- Kommo ayar ekranında:
  - API bağlantı durumu,
  - subdomain ve kaynağı,
  - token kaynağı (değer gizli),
  - Program Pipeline,
  - legacy pipeline adayı,
  - güvenli wp-config geçiş şablonu
  gösterilir.
- Manuel **Kommo Bağlantısını Yeniden Test Et** butonu gerçek canlı testi zorlar.
- Veritabanı şeması değişmez; `MMC_DB_VERSION` **1.3.7** olarak kalır.

## Güvenlik

- Token değeri ekranda, logda, URL'de veya WordPress option alanında gösterilmez/saklanmaz.
- Eski tokenı MMC'ye kopyalamak yerine Kommo'dan yeni/yenilenmiş uzun ömürlü token üretip `wp-config.php` içinde `MMC_KOMMO_TOKEN` olarak taşımak önerilir.
- WooCommerce sipariş pipeline'ı ile MMC program takip pipeline'ı otomatik birleştirilmez.
- Kommo API testleri salt-okunurdur; lead/pipeline kaydı oluşturmaz veya değiştirmez.
- WooCommerce, Tickera, PayTR, QR, MDG ve Okul Tanıtım verilerine yazma yoktur.

---

# Madagaskar Management Center v1.3.13

Bu sürüm **Code Snippets envanterini salt-okunur analiz eder ve gerçek riskleri genel “snippet var” uyarısından ayırır.**

## v1.3.13 — Snippet Envanteri & Çakışma Merkezi

- Sistem & Yetkiler içine yeni **Snippet Envanteri** ekranı eklendi.
- Code Snippets tablosu salt-okunur taranır; hiçbir snippet otomatik kapatılmaz, silinmez veya değiştirilmez.
- Her snippet için:
  - aktif/pasif durumu,
  - Üretim / Test-Tanı / Geçici / Legacy / İncele sınıfı,
  - tanımladığı global fonksiyonlar,
  - kullandığı WordPress/WooCommerce hook'ları,
  - shortcode adları,
  - kod hash'i,
  - olası çakışmalar,
  - koru / incele / pasife alma adayı önerisi
  gösterilir.
- Aktif snippet'lerde aynı global fonksiyon veya aynı shortcode adı tespit edilirse çakışma uyarısı üretilir.
- Benzer işlev alanındaki aktif snippet'ler (Kommo, sosyal paylaşım, hukuk/iletişim, SEO, Bilet Al, Biletlerim, etkinlik vb.) inceleme adayı olarak birlikte gösterilir.
- **test / diagnostic / debug / deneme** isimli aktif snippet'ler öncelikli uyarı adayıdır.
- Eski **Madagaskar V5 Finans Güncellemesi** kodu tespit edilirse Legacy + uyarı olarak işaretlenir.
- Sağlık ekranındaki Code Snippets satırı artık yalnız gerçek risk varsa **Uyarı** olur; risk yoksa **Sağlıklı** olabilir.
- Veritabanı şeması değişmez; `MMC_DB_VERSION` **1.3.7** olarak kalır.

## Güvenlik

- Snippet kodları yalnız okunur.
- Otomatik deactivate/delete/update yoktur.
- WooCommerce, Tickera, PayTR, QR, MDG ve Okul Tanıtım verilerine yazılmaz.
- Kullanıcı snippet'i kapatmak isterse önce Code Snippets ekranında manuel olarak kodu doğrular.
- Pasif eski sürümler için Export sonrası arşiv/Trash önerisi yalnız bilgi amaçlıdır.

---

# Madagaskar Management Center v1.3.12

Bu sürüm **Kurulum & Sağlık ekranındaki Tickera doğrulamasını güçlendirir, aktif programın WooCommerce→MDG→Tickera zincirini ayrı kontrol eder ve eski MMC bildirim gürültüsünü temizler.**

## v1.3.12 — Sağlık Kontrolü Doğrulama

- Tickera artık yalnız `TC` sınıfına bakılarak değerlendirilmez.
- Tickera doğrulamasında şu sinyaller birlikte kullanılır:
  - aktif Tickera eklenti kaydı,
  - `TC` / `TC_VERSION`,
  - Tickera fonksiyon ve post-type sinyalleri,
  - aktif programdaki gerçek `tickera_event_id` eşleşmeleri.
- Aktif program için yeni **WooCommerce → MDG → Tickera Zinciri** sağlık satırı eklendi.
- Bu zincirde MMC Program ID, MDG Event ID, satış nesnesi eşleşmesi, seans sayısı ve Tickera event ID'leri karşılaştırılır.
- Kommo uyarı metni netleştirildi: API yapılandırılmadığında MMC çalışmaya devam eder, yalnız otomatik CRM/AI senkronu beklemede kalır.
- Code Snippets aktifse `wp_snippets` tablosunda Madagaskar ilişkili aktif snippet adayları salt-okunur aranır; bulunursa snippet ID/adları sağlık ekranında gösterilir.
- MMC sayfalarında yalnız bilinen iki operasyon dışı bildirim gizlenir:
  - **Madagaskar V5 Finans Güncellemesi**
  - **Tickera - Custom Forms Activation** reklam bildirimi
- Gerçek warning/error bildirimleri görünmeye devam eder.
- Veritabanı şeması değişmediği için `MMC_DB_VERSION` **1.3.7** olarak kalır.

## Güvenlik

- WooCommerce sipariş, ürün ve varyasyonlarına yazma yoktur.
- Tickera event/bilet/QR verileri değiştirilmez.
- PayTR akışına dokunulmaz.
- MDG `events/sessions/ticket_types/order_map` tabloları salt okunur sağlık doğrulaması için kullanılır.
- Code Snippets kayıtları yalnız okunur; otomatik pasife alma veya silme yapılmaz.
- Kommo yapılandırması veya token değerleri değiştirilmez.

---

# Madagaskar Management Center v1.3.11

Bu sürüm **Sistem & Yetkiler ve diğer gizlenmiş MMC ayrıntı ekranlarının WordPress erişim kaydını korur**. Sol menü sade kalır; kartlardan açılan ayrıntı sayfaları artık doğrudan erişilebilir.

## v1.3.11 — Güvenli Gizli Sayfalar & Arayüz Temizliği

- `remove_submenu_page()` ile MMC ayrıntı sayfalarının kayıt zincirini kesme yöntemi kaldırıldı.
- `mmc-roles`, `mmc-system`, `mmc-preparation`, `mmc-events`, `mmc-sales`, `mmc-field` ve diğer ayrıntı ekranları WordPress'te kayıtlı kalır.
- Bu ayrıntı ekranları yalnız sol yönetim menüsünde JavaScript ile görsel olarak gizlenir.
- Kart bağlantıları `admin.php?page=...` üzerinden mevcut callback ve capability kontrolleriyle çalışmaya devam eder.
- **Yetkiler** ve **Kurulum & Sağlık** için kullanılan `mmc_manage_settings` yetkisi değiştirilmez.
- Yönetici ve Madagaskar Yönetici rollerinin mevcut yetki modeli korunur.
- Hub sayfalarındaki test amaçlı **Güvenli menü modu** kutusu kaldırıldı.
- Rutin başarı/güncelleme bildirimleri hub ekranlarında gizlenir; warning/error mesajları görünmeye devam eder.
- Veri tabanı şeması değişmediği için `MMC_DB_VERSION` **1.3.7** olarak kalır.

## Güvenlik

- WooCommerce, Tickera, PayTR, QR ve MDG satış motoruna müdahale edilmez.
- MDG ve Okul Tanıtım veri tablolarında değişiklik yoktur.
- Eski sayfa slug, callback, nonce ve form action yapıları korunur.
- Sol menü sadeleştirme yalnız görsel katmanda yapılır.

---

# Madagaskar Management Center v1.3.10

Bu sürüm **eski Madagaskar Bilet Yönetimi modüllerini görevlerine göre doğru MMC merkezlerine otomatik dağıtır** ve merkez ekranlarını mobil kullanım için sadeleştirir.

## v1.3.10 — Akıllı Modül Dağıtımı

- Bilet Yönetimi artık yalnız bilet motorunun çekirdek operasyon ekranlarını tutar.
- Yinelenen **Genel Bakış** kartları başlık bazında tekilleştirilir.
- Eski MDG modülleri başlık/slug üzerinden güvenli biçimde sınıflanır:
  - **Satışlar ve Biletler / Satış Raporları / Müşteri-Bilet / İadeler** → Satış & Müşteri
  - **Gider ve Kârlılık / Finans** → Finans
  - **V2 Pazarlama / Marketing** → Pazarlama
  - **V3 CRM / Kommo** → Kommo & AI
  - **Entegrasyonlar / Geliştirici Araçları** → Sistem & Yetkiler
  - Genel legacy **Salonlar / Etkinlikler** → Salon & Etkinlik
- Salon & Etkinlik merkezinde legacy MDG bakım ekranları açıkça **Legacy** etiketiyle gösterilir.
- Pazarlama, Kommo & AI ve Finans artık merkez ekranlarıdır; MMC sayfası ile ilgili legacy MDG aracı aynı merkezde açılır.
- Merkez sayfalarındaki ikinci **Aktif Program** kartı kaldırıldı; üstteki MMC aktif program şeridi tek kaynak olarak kullanılır.
- Hub sayfalarında yalnız rutin başarı/güncelleme bildirimleri gizlenir; warning/error bildirimleri görünmeye devam eder.
- Dinamik olarak yakalanan MDG slug'ları `mdg-` ile başlamasa bile doğru MMC merkezinin menü vurgusu korunur.
- Veritabanı şeması değişmez; `MMC_DB_VERSION` **1.3.7** olarak kalır.

## Güvenlik

- WooCommerce sipariş, ürün ve varyasyonlarına yazma yoktur.
- Tickera event/bilet/QR verileri değiştirilmez.
- PayTR akışına dokunulmaz.
- MDG `events/sessions/ticket_types/order_map` tabloları değiştirilmez.
- Okul Tanıtım verileri ve görev/rota kayıtları taşınmaz.
- Tüm legacy sayfaların mevcut slug, callback ve form action yapısı korunur.

---

# Madagaskar Management Center v1.3.9

Bu sürüm **tek Madagaskar menüsünü sadeleştirir ve ayrıntılı ekranları iş merkezleri altında toplar**. İşlevsel sayfalar, slug'lar, callback'ler, form action'lar ve veri tabloları korunur.

## v1.3.9 — Sade Yönetim Menüsü

Görünür ana menü başlıkları:
- Kontrol Paneli
- Programlar
- Hazırlık & Bölge
- Salon & Etkinlik
- Bilet Yönetimi
- Satış & Müşteri
- Okul Tanıtım & Saha
- Pazarlama
- Kommo & AI
- Operasyon
- Finans
- Raporlar
- Program Bütünlüğü
- Sistem & Yetkiler

Ayrıntılı sayfalar ilgili merkez içinde kart olarak gösterilir:
- Hazırlık & Bölge → Program Hazırlığı, Bölge Veri Ambarı, Nüfus ve Eğitim Verisi, İş Akışı
- Salon & Etkinlik → Salonlar, Salon & Tahsis, Etkinlik & Seans, Satış Hazırlığı
- Bilet Yönetimi → mevcut MDG üretim/etkinlik araçları
- Satış & Müşteri → MMC Satış & Doluluk + MDG Satış Raporları + Müşteri/Bilet Listeleri
- Okul Tanıtım & Saha → MMC Okul/Saha + mevcut Okul Tanıtım/MEBBİS/rota/görev ekranları
- Sistem & Yetkiler → Yetkiler + Kurulum & Sağlık

## Güvenlik

- Bu sürüm yalnız WordPress yönetim navigasyonunu değiştirir.
- WooCommerce, Tickera, PayTR, QR ve MDG satış motoruna yazma yapılmaz.
- `mdg_events`, `mdg_sessions`, `mdg_ticket_types`, `mdg_order_map` değiştirilmez.
- Okul Tanıtım veri tabloları ve saha görev kayıtları taşınmaz.
- Gizlenen ayrıntı sayfaları doğrudan URL ve mevcut callback'leriyle çalışmaya devam eder.
- MMC yetkisi olmayan kullanıcıların eski menü davranışı değiştirilmez.
- Saha personelinin bağımsız **Görevlerim** menüsü korunur.
- Veritabanı şeması değişmediği için `MMC_DB_VERSION` **1.3.7** olarak kalır.

---

# Madagaskar Management Center v1.3.8

Bu sürüm **MMC + Madagaskar Bilet Yönetimi + Okul Tanıtım yönetim ekranlarını tek Madagaskar üst menüsünde toplar**. Veri kaynakları ve çalışan motorlar ayrışık kalır; değişiklik yalnız yönetim navigasyonundadır.

## v1.3.8 — Tek Yönetim Menüsü / Navigation Hub

- WordPress yönetiminde MMC, MDG ve Okul Tanıtım için tek ana çatı **Madagaskar** olur.
- MMC yetkisi olan yöneticilerde eski `mdg-dashboard` ve `mad-okul` üst menüleri gizlenir.
- Eski MDG ve Okul Tanıtım sayfalarının slug, callback, form action ve veri tabloları değiştirilmez.
- **Bilet Yönetimi** merkezi, o anda sisteme kayıtlı tüm `mdg-dashboard` alt sayfalarını dinamik olarak listeler; ek MDG modülleri varsa ayrıca görünür.
- **Okul Tanıtım** merkezi, o anda sisteme kayıtlı tüm `mad-okul` alt sayfalarını dinamik olarak listeler.
- Eski `mdg-*` ve `mad-okul*` ekranlarında WordPress sol menü vurgusu Madagaskar çatısında kalır.
- Aktif MMC Program ID eski ekranlara taşınan bağlantılarda korunur.
- **Görevlerim** menüsü saha personelinin ayrı yetki akışı için bağımsız bırakılır.
- MMC yetkisi olmayan kullanıcıların eski menü erişimi değiştirilmez.
- MMC devre dışı bırakılırsa eski MDG ve Okul Tanıtım üst menüleri otomatik olarak geri döner.
- Bu sürümde veritabanı şeması değişmez; `MMC_DB_VERSION` 1.3.7 olarak kalır.

## Güvenlik sınırları

- WooCommerce siparişleri, ürünleri ve varyasyonları değiştirilmez.
- Tickera event/bilet/QR kayıtlarına yazılmaz.
- PayTR akışına müdahale edilmez.
- MDG `events/sessions/ticket_types/order_map` tabloları navigasyon birleşiminden etkilenmez.
- Okul Tanıtım okul, program, görev ve rota kayıtları taşınmaz veya yeniden yazılmaz.
- Birleşim yalnız WordPress admin menü görünümünü değiştirir.

---

# Madagaskar Management Center v1.3.7

Bu sürüm **MMC Program ID ile ilk Madagaskar Bilet Yönetimi motorunu kalıcı olarak birbirine bağlar**.

## v1.3.7 — MDG Bilet Motoru Köprüsü

- Yeni `mmc_mdg_event_bridge` tablosu eklendi.
- Tek gerçek yönetim kimliği MMC `program_id` olarak korunur.
- MMC Program → MMC Event → MDG Event → MDG Session → WooCommerce → Tickera → sipariş zinciri doğrulanır.
- Eski Madagaskar satış tablolarına kolon eklenmez ve kayıt yazılmaz; köprü MMC tarafında tutulur.
- Güvenli otomatik eşleştirme WooCommerce ürün/varyasyon ve Tickera event kimliklerinin ortaklığıyla yapılır.
- Yalnız il/ilçe/tarih benzerliği otomatik bağlantı için yeterli kabul edilmez.
- Bütünlük Merkezi artık MDG motor sürümünü, Program↔MDG Event bağını, il/ilçe/tarih/salon/seans saatlerini, satış nesnesi kimliklerini ve MDG↔MMC satış mutabakatını gösterir.
- MDG ve MMC satış mutabakatında sipariş, sipariş satırı, bilet adedi ve kapasite/kişi birimleri karşılaştırılır; aynı WooCommerce satışı iki kez gelir olarak yazılmaz.
- MDG ve MMC ciro değerleri görünür biçimde karşılaştırılır; MDG `line_total` vergi hariç olabildiği için ciro farkı tek başına kritik hata sayılmaz.
- MMC aktif program şeridi artık `mdg-*` yönetim ekranlarında da görünür.
- Bütünlük Merkezi ve aktif program kısayollarına **MDG Bilet** bağlantısı eklendi.
- Eşleşme kesin değilse Bütünlük Merkezi aday MDG etkinliklerini gösterir ve yönetici kontrollü manuel bağlama yapılabilir.

## Güvenlik sınırları

- MDG `events`, `sessions`, `ticket_types` ve `order_map` tabloları salt okunur kullanılır.
- WooCommerce ürünleri, Tickera etkinlikleri ve siparişler köprü kurulurken değiştirilmez.
- Bir MDG Event aynı anda iki farklı MMC Program ID ile bağlanamaz.
- Otomatik backfill yalnız güçlü ve tekil WooCommerce/Tickera kimlik eşleşmesinde bağlantı kurar.
- Belirsiz durumda sistem bağlantı oluşturmaz.

## Güncelleme

1. Eklentiyi v1.3.7 ile değiştirin.
2. WordPress eklentiyi yüklediğinde MMC veritabanı şema sürümü **1.3.7** olur ve köprü tablosu oluşturulur.
3. Madagaskar → Program Bütünlüğü ekranını açın.
4. İlgili Program ID için **MDG Bilet Motoru**, **MMC ↔ MDG Etkinlik Köprüsü**, **MDG Tarih / Salon / Seans**, **MDG / WooCommerce / Tickera Kimliği** ve **MDG ↔ MMC Satış Mutabakatı** satırlarını kontrol edin.
5. Tek güçlü aday varsa **MDG Bağını Kur** düğmesini kullanabilirsiniz; sürüm yükseltmesi sırasında güvenli eşleşmeler ayrıca otomatik backfill edilir.
